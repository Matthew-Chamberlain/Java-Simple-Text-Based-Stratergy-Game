/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/**
 *
 * @author mattc
 */
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author comqaam
 */
public class T8Persistance {
    CORE game, game2;
    public T8Persistance() {
    }
    
     @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        game = new Tournament("Matt");
        game2 = new Tournament("Mott", "olenka.txt");
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
 
    //just a local method to check a String for contents
    private boolean containsText(String text, String[] s) {
        boolean check = true;
        for(int i=0; i < s.length; i++)
        check = check && text.contains(s[i]);
        return check;
    }
    
    /** Test that checks whether the save and load features work by saving the game and calling the load method on a new tournament object and then getting the game state to see if they match
     * 
     */
    @Test
    public void saveAndLoadGame()
    {
        game.enterChampion("Xenon");
        game.saveGame("Tournament.dat");
        CORE game3 = new Tournament("aaa");
        game3.loadGame("Tournament.dat");
        String result = game3.toString();
        String[] test = {"Matt","500","false","Xenon"};
        boolean actual = containsText(result,test);
        assertTrue(actual);
        
    }
    
    /** Test that checks whether the challenges are correctly read from a file by comparing them against a tournament object where the challenges are hard coded in
     * 
     */
    @Test
    public void readChallengesFromFile()
    {
        String hardCodedChallenges = game.getAllChallenges();
        String fileChallenges = game2.getAllChallenges();
        boolean actual = hardCodedChallenges.equalsIgnoreCase(fileChallenges);
        assertTrue(actual);
    }
}