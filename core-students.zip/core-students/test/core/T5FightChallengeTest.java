/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author aam
 */
public class T5FightChallengeTest {
    CORE game;
    
    public T5FightChallengeTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        game = new Tournament("Jean");
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    
//Wizards    
    // Wizard facing magic
    
    /** Tests a wizard facing a magic challenge, expected result 0 as champion should win
     * 
     */
    @Test
    public void wizardFacingMagicWins() {
        int expected = 0;
        game.enterChampion("Ganfrank");
        int actual = game.fightChallenge(1);
        assertEquals(expected, actual);
    }
    
    /** tests that the correct amount of money is added to the treasury when wizard wins
     * 
     */
    @Test
    public void wizardFacingMagicWinsMoney() {
        int expected = 1000-400+100;
        game.enterChampion("Ganfrank");
        game.fightChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Tests that a champion loses a challenge if they do not have the required skill level expected result should be 1
     * 
     */
    @Test
    public void wizardFacingMagicLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Neon");
        int actual = game.fightChallenge(1);
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is deducted when wizard loses on skill level
     * 
     */
    @Test
    public void wizardFacingMagicLosesOnSkillMoneyDeducted() {
        int expected = 1000-300-100;
        game.enterChampion("Neon");
        game.fightChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
      
    /** checks that a champions state is set to dead after losing a challenge
     * 
     */
    @Test
    public void wizardLosingIsDead() {
        game.enterChampion("Neon");
        game.fightChallenge(1);
        boolean actual = game.getChampionDetails("Neon").toLowerCase().contains("dead");
        assertTrue(actual);
    }
    
    //checking withdrawal of dead champion
    /** Tests that a dead champion cannot be retired
     * 
     */
    @Test
    public void cantWithdrawDead() {
        int expected = 1;
        game.enterChampion("Neon");
        game.fightChallenge(1);
        int actual= game.retireChampion("Neon");
        assertEquals(actual,expected);
    }
    
    /** Tests that the treasury is not affected when trying to retire a dead champion
     * 
     */
    @Test
    public void cantWithdrawDeadMoneyNotAffected() {
        int expected = 1000-300-100;
        game.enterChampion("Neon");
        game.fightChallenge(1);
        game.retireChampion("Neon");
        int actual= game.getMoney();
        assertEquals(actual,expected);
    }

    /** Tests what happens if you try to face a challenge that does not exist, expected result should be -1
     * 
     */
    @Test
    public void wizardFacingNoSuchMagic() {
        int expected = -1;
        game.enterChampion("Ganfrank");
        int actual = game.fightChallenge(14);
        assertEquals(expected, actual);
    } 
    
    /** Tests that the money in the treasury is not affected after trying to fight a challenge that does not exist
     * 
     */
    @Test
    public void wizardFacingNoSuchMagicMoneyTest()
    {
        int expected = 600;
        game.enterChampion("Ganfrank");
        game.fightChallenge(14);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    // Wizard facing fight
    /** Tests wizard facing a fight challenge, expected result 0 as wizard should win
     * 
     */
    @Test
    public void wizardFacingFightWins() {
        int expected = 0;
        game.enterChampion("Ganfrank");
        int actual = game.fightChallenge(2);
        assertEquals(expected, actual);
    }
    
    /** tests that the prize money of the challenge is added to the treasury after wizard wins
     * 
     */
   @Test
    public void wizardFacingFightWinsMoneyAdded() {
        int expected = 1000-400+120;
        game.enterChampion("Ganfrank");
        game.fightChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    } 
    
    /** tests that a wizard loses a fight challenge if they do not have the required skill level
     * 
     */
    @Test
    public void wizardFacingFightLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Neon");
        int actual = game.fightChallenge(2);
        assertEquals(expected, actual);
    }
    
    /** Tests that correct amount of money is deducted from treasury when wizard loses fight challenge based on skill level
     * 
     */
    @Test
    public void wizardFacingFightLosesOnSkillMoneyDeducted() {
        int expected = 1000-300-100;
        game.enterChampion("Neon");
        game.fightChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    // Wizard facing mystery
    /** Tests what happens when a wizard faces a mystery challenge with a higher enough skill level. expected result is 0 as wizard should win
     * 
     */
    @Test
    public void wizardFacingMysteryWins() {
        int expected = 0;
        game.enterChampion("Ganfrank");
        int actual = game.fightChallenge(3);
        assertEquals(expected, actual);
    }
    
    /** tests that the correct amount of money is added to the treasury after wizard wins mystery challenge
     * 
     */
   @Test
    public void wizardFacingMysteryWinsMoneyAdded() {
        int expected = 1000-400+150;
        game.enterChampion("Ganfrank");
        game.fightChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    } 
    
    /** Tests that a wizard loses mystery challenge if they have a lower skill level than the challenge requires
     * 
     */
    @Test
    public void wizardFacingMysteryLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Neon");
        int actual = game.fightChallenge(3);
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is deducted from the treasury after wizard loses
     * 
     */
    @Test
    public void wizardFacingMysteryLosesOnSkillMoneyDeducted() {
        int expected = 1000-300-150;
        game.enterChampion("Neon");
        game.fightChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
   
//Warriors
    //Warrior facing magic - not allowed
    /** Tests that makes sure warrior cannot face magic challenge, expected result 2 as it represents no available champion
     * 
     */
    @Test
    public void warriorFacingMagicNotAllowed() {
        int expected = 2;
        game.enterChampion("Argon");
        game.fightChallenge(1);
        int actual = game.fightChallenge(1);
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is deducted when there is no available champion to face the challenge
     * 
     */
    @Test
    public void warriorFacingMagicNotAllowedMoneyDeducted() {
        int expected = 0;
        game.enterChampion("Argon");
        game.fightChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
  
    //Warrior facing fight
    /** Tests that a warrior wins a fight challenge if they have the required skill level, expected result 0 as that represents challenge won
     * 
     */
    @Test
    public void warriorFacingFightAllowedWins() {
        int expected = 0;
        game.enterChampion("Argon");
        int actual = game.fightChallenge(2);
        assertEquals(expected, actual);
    }
      
    /** Tests that the correct amount of money is added to the treasury after warrior beats fight challenge
     * 
     */
    @Test
    public void warriorFacingFightAllowedWinsMoneyAdded() {
        int expected = 220;
        game.enterChampion("Argon");
        game.fightChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Tests that a warrior loses a fight challenge if they do not have the required skill level
     * 
     */
    @Test
    public void warriorFacingFightAllowedLosesOnSkill() {
        int expected = 1;
        game.enterChampion("Flimsi");
        int actual = game.fightChallenge(2);
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is deducted when a warrior loses on skill
     * 
     */
    @Test
    public void warriorFacingFightAllowedLosesMoneyDeducted() {
        int expected = 680;
        game.enterChampion("Flimsi");
        game.fightChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    //Warrior facing mystery - not allowed
    
    /** Test what happens when a warrior tries to face a magic challenge, expected result is 2 as there should he no available champion to face the challenge
     * 
     */
    @Test
    public void warriorFacingMysteryNotAllowed() {
        int expected = 2;
        game.enterChampion("Argon");
        //game.fightChallenge(3);
        int actual = game.fightChallenge(3);
        assertEquals(expected, actual);
    }
    
    /** test that the correct amount of money is deducted if there is no champion to meet the challenge
     * 
     */
    @Test
    public void warriorFacingMysteryNotAllowedMoneyDeducted() {
        int expected = -50;
        game.enterChampion("Argon");
        game.fightChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    //Dragons - write your own tests
    
    /** Tests what happens when a dragon tries to face a magic challenge, expected result is 2 as there should be no available champion to meet the challenge
     * 
     */
    @Test
    public void dragonFacingMagicNotAllowed()
    {
        int expected = 2;
        game.enterChampion("Drabina");
        int actual = game.fightChallenge(1);
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is deducted when there is no available champion to face the challenge
     * 
     */
    @Test
    public void dragonFacingMagicNotAllowedMoneyDeducted()
    {
        int expected = 400;
        game.enterChampion("Drabina");
        game.fightChallenge(1);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Tests what happens when a dragon faces a fight challenge with the required skill level, expected result is 0 as dragon should win
     * 
     */
    @Test
    public void dragonFacingFightAllowedWins()
    {
        int expected = 0;
        game.enterChampion("Drabina");
        int actual = game.fightChallenge(2);
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is added when dragon wins a challenge
     * 
     */
    @Test
    public void dragonFacingFightAllowedWinsMoneyAdded()
    {
        int expected = 620;
        game.enterChampion("Drabina");
        game.fightChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Tests what happens when a dragon faces a challenge with a lower than required skill level. expected result is 1 as dragon should lose
     * 
     */
    @Test
    public void dragonFacingFightAllowedLosesOnSkill()
    {
        int expected = 1;
        game.enterChampion("Drabina");
        int actual = game.fightChallenge(8);
        assertEquals(expected, actual);
    }
    
    /** Tests that  the correct amount of money is deducted when dragon loses
     * 
     */
    @Test
    public void dragonFacingFightAllowedLosesMoneyDeducted()
    {
        int expected = 330;
        game.enterChampion("Drabina");
        game.fightChallenge(8);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Test what happens when a dragon that can't talk tries to face a mystery challenge. expected result 2 as there should be no available champion to face the challeng  e 
     * 
     */
    @Test
    public void dragonFacingMysteryCantTalkNotAllowed()
    {
        int expected = 2;
        game.enterChampion("Drabina");
        int actual = game.fightChallenge(3);
        assertEquals(expected, actual);
    }
    
    /** Tests that money is deducted when a dragon can't meet a mystery challenge
     * 
     */
    @Test
    public void dragonFacingMysteryCantTalkNotAllowedMoneyDeducted()
    {
        int expected = 350;
        game.enterChampion("Drabina");
        game.fightChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Test what happens when a dragon that can talk faces a mystery challenge. expected result 0 as dragon should win
     * 
     */
    @Test
    public void dragonFacingMysteryCanTalkAllowedWins()
    {
        int expected = 0;
        game.enterChampion("Golum");
        int actual = game.fightChallenge(3);
        assertEquals(expected, actual);
    }

    /** Tests that the correct amount of money is added when dragon wins mystery challenge
     * 
     */
    @Test
    public void dragonFacingMysteryCanTalkAllowedWinsMoneyAdded()
    {
        int expected = 650;
        game.enterChampion("Golum");
        game.fightChallenge(3);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Test what happens when a dragon that can talk faces a mystery challenge with a lower than required skill level, expected result 1 as dragon should lose
     * 
     */
    @Test
    public void dragonFacingMysteryCanTalkAllowedLosesOnSkill()
    {
        int expected = 1;
        game.enterChampion("Golum");
        int actual = game.fightChallenge(9);
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is taken away when a dragon loses mystery challenge
     * 
     */
    @Test
    public void dragonFacingMysteryCanTalkAllowedLosessMoneyDeducted()
    {
        int expected = 200;
        game.enterChampion("Golum");
        game.fightChallenge(9);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
}
