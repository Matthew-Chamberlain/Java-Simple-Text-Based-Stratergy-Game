/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author comqaam
 */
public class T6ChampionRetiredTest {
    CORE game;
    public T6ChampionRetiredTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        game = new Tournament("OO");
        game.enterChampion("Ganfrank");
        game.enterChampion("Elblond");
        game.enterChampion("Neon");
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    
    /** Tests a successful retirement of a champion. expected result should be 0 which represents champion retired
     * 
     */
    @Test
    public void retireChampionTestResult0(){
        int expected = 0;
        int actual = game.retireChampion("Neon");
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is added to the treasury when a champion is retired
     *  Expected result is 300 which is 1000 - the cost of ganfrank elbond and neon plus the cost of neon /2 which is the amount the player will receive upon retiring them
     * 
     */
    @Test
    public void retireChampionTestMoneyAdded(){
        int expected = 1000 -(400+150+300)+ 300/2;
        game.retireChampion("Neon");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** checks to see that a retired champion is no longer in the team by calling the isInPlayersTeam method parsing neon, expected result should be false
     * 
     */
    @Test
    public void retireChampionNotInTeam(){
        game.retireChampion("Neon");
        boolean actual = game.isInPlayersTeam("Neon");
        assertFalse(actual);
    }
    
    /** checks to see if a retired champion is now in the reserves expected result should be true
     * 
     */
    @Test
    public void retireChampionInReserve(){
        game.retireChampion("Neon");
        String list = game.getReserve();
        boolean actual = list.contains("Neon");
        assertTrue(actual);
    }
    
    /** Test trying to retire a champion that is not in the team. expected result should be 2 which represents not in team
     * 
     */
    @Test
    public void retireChampionTestResult2(){
        int expected = 2;
        int actual = game.retireChampion("Flimsi");
        assertEquals(expected, actual);
    }
    
    /** tests that no money is added when trying to retire a champion, the expected result should be 150 which is the amount in the treasury after adding the 3 champions the setup
     * 
     */
    @Test
    public void retireChampionTestResult2Money(){
        int expected = 150;
        game.retireChampion("Flimsi");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Test trying to retire a champion that does not exist. expected result should be -1 which represents a non existant champion
     * 
     */
    @Test
    public void retireNoSuchChampionTestResultNegative1(){
        int expected = -1;
        int actual = game.retireChampion("Boggle");
        assertEquals(expected, actual);
    }
    
    /** tests that no money is added if the player tries to retire a non existent champion. expected result is 150, teh amount of money left in the treasury after adding the 3 champions to the team
     * 
     */
    @Test
    public void retireNoSuchChampionTestMoney(){
        int expected = 150;
        game.retireChampion("Boggle");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
        
    /** Tests that a non existent champion is not in the players team, expected result is false
     * 
     */
    @Test
    public void retiredNoSuchChampionNotInTeam(){
        game.retireChampion("Boggle");
        boolean actual = game.isInPlayersTeam("Boggle");
        assertFalse(actual);
    }
    
    /** Tests that a non existent champion is not in reserve after retirement, expected result is fasle
     * 
     */
    @Test
    public void retiredNoSuchChampionNotInReserve(){
        game.retireChampion("Boggle");
        String list = game.getReserve();
        boolean actual = list.contains("Boggle");
        assertFalse(actual);
    }
    
    /** Tests retiring a dead champion, expected result is 1 which represents that a champion is dead
     * 
     */
    @Test
    public void retireDeadChampion()
    {
        int expected = 1;
        game.fightChallenge(7);
        int actual = game.retireChampion("Neon");
        assertEquals(expected, actual);
    }
    
    /** Tests that the money does not increase after trying to retire a dead champion
     * 
     */
    @Test
    public void retireDeadChampionTestMoney()
    {
        int expected = -50;
        game.fightChallenge(7);
        game.retireChampion("Neon");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** tests to check that a dead champions stays in the team after the player tries to retire them
     * 
     */
    @Test
    public void DeadChampionStillInTeam()
    {
        game.fightChallenge(7);
        game.retireChampion("Neon");
        boolean actual = game.isInPlayersTeam("Neon");
        assertTrue(actual);
    }
    
    /** Checks that a dead champion is not in the reserve after the player tries to retire them
     * 
     */
    @Test
    public void DeadChampionNotInReserve()
    {
        game.fightChallenge(7);
        game.retireChampion("Neon");
        boolean actual = game.isInReserve("Neon");
        assertFalse(actual);
    }
    
}
