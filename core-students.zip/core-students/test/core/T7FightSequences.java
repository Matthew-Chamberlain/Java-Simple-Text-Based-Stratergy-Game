/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author comqaam
 */
public class T7FightSequences {
    CORE game;
    public T7FightSequences() {
    }
    
     @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        game = new Tournament("Jean");
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    
    //Action sequences
    
    /** Tests to check that a dead champion cannot be used again expected result is 2 which represents no available challenge
     * 
     */
    @Test
    public void warriorDeadUsedAgain() {
        int expected = 2;
        game.enterChampion("Flimsi");
        game.fightChallenge(2);  //should be dead
        int actual = game.fightChallenge(2); //re-used ?
        assertEquals(expected, actual);
    }
    
    /** tests to check that the correct amount of money is deducted if a player tries to use a dead champion
     * 
     */
    @Test
    public void warriorDeadUsedAgainMoney() {
        int expected = 1000-200-120-120;
        game.enterChampion("Flimsi");
        game.fightChallenge(2);  //should be dead
        game.fightChallenge(2); //re-used ?
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Tests what happens when a player withdraws a champion and then attempts a challenge. expected result is 2 as there should be no available champion to meet the challenge
     * 
     */
    @Test
    public void warriorWithdrawnBeforeFight() {
        int expected = 2;
        game.enterChampion("Argon");
        game.retireChampion("Argon");
        int actual = game.fightChallenge(2); //used ?
        assertEquals(expected, actual);
    }
    
    /** Tests the correct amount of money is deducted when the player withdraws a champion before attempting a challenge
     * 
     */
    @Test
    public void warriorWithdrawnBeforeFightMoney() {
        int expected = 1000-900+450-120;
        game.enterChampion("Argon");
        game.retireChampion("Argon");
        game.fightChallenge(2);  //not available
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** tests that a player is defeated when they lose a challenge with no money left and no available champions to retire
     *  
     */
    
    @Test
    public void defeatAchieved() {
        int expected = 3;
        game.enterChampion("Rudolf");
        game.enterChampion("Flimsi");
        game.fightChallenge(8);  //lose
        game.fightChallenge(8);  //lose
        game.fightChallenge(8);  //no one left
        int actual = game.fightChallenge(8);  //no one left
        assertEquals(expected, actual);
    }
    
    /** Tests the correct amount of money is deducted
     * 
     */
    @Test
    public void defeatWithWithdrawalMoney() {
        int expected = 1000-400-200-170+100-170-170;
        game.enterChampion("Rudolf");
        game.enterChampion("Flimsi");
        game.fightChallenge(8);  //lose
        game.retireChampion("Flimsi");
        game.fightChallenge(8);  //no one left
        game.fightChallenge(8);  //no one left
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Tests that the player is not defeated if they still have money or a champion still available to be withdrawn
     * expected result is 2 which represent challenge lost due to no champions
     * 
     */
    @Test
    public void defeatNotAchieved() {
        int expected = 2;
        game.enterChampion("Drabina");
        game.enterChampion("Flimsi");
        game.fightChallenge(4);  //lose as no one available
        game.fightChallenge(4);  //lose as no one available
        int actual = game.fightChallenge(4);  //lose as no one available
        assertEquals(expected, actual);
    }
    
    /** Tests that the correct amount of money is taken away, expected result is -300
     * 
     */
    @Test
    public void defeatNotAchievedMoney() {
        int expected = 1000-500-200-200-200-200;
        game.enterChampion("Drabina");
        game.enterChampion("Flimsi");
        game.fightChallenge(4);  //lose as no one available
        game.fightChallenge(4);  //lose as no one available
        game.fightChallenge(4);  //lose as no one available
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

    /** Tests if player is defeated after retiring a champion expected result is 3 which represents defeated
     * 
     */
    @Test
    public void defeatAchievedAfterWithdraw() {
        int expected = 3;
        game.enterChampion("Drabina");
        game.enterChampion("Flimsi");
        game.fightChallenge(4);  //lose as no one available
        game.fightChallenge(4);  //lose as no one available
        game.retireChampion("Drabina");
        game.retireChampion("Flimsi"); //no one in Team
        game.fightChallenge(4);  //lose as no one available
        int actual = game.fightChallenge(4);  //lose as no one available
        assertEquals(expected, actual);
    }
    
    /** Tests the correct amount of money is in the treasury
     * 
     */
    @Test
    public void defeatAchievedAfterWithdrawMoney() {
        int expected = 1000-500-200-200-200+250+100-200-200;
        game.enterChampion("Drabina");
        game.enterChampion("Flimsi");
        game.fightChallenge(4);  //lose as no one available
        game.fightChallenge(4);  //lose as no one available
        game.retireChampion("Drabina");
        game.retireChampion("Flimsi"); //no one in Team
        game.fightChallenge(4);  //lose as no one available
        game.fightChallenge(4);  //lose as no one available
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
// Add your own tests    
    
    /** Tests what happens if you try to use a retired champion twice, expected result is 2 which represents no available champions
     * 
     */
    @Test
    public void retiredChampionUsedAgain()
    {
        int expected = 2;
        game.enterChampion("Argon");
        game.fightChallenge(2);
        game.retireChampion("Argon");
        int actual = game.fightChallenge(2);
        assertEquals(expected, actual);
        
    }
    
    /** Tests that the correct amount of money is deducted when the player tries to use a retired champion again
     * 
     */
    public void retiredChampionUsedAgainMoneyTest()
    {
        int expected = 430;
        game.enterChampion("Argon");
        game.fightChallenge(2);
        game.retireChampion("Argon");
        game.fightChallenge(2);
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }

}
