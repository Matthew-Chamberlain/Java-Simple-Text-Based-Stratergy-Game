/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author jp14adn
 */
public class T4ChampionEnteredTest {
    CORE game;
    
    public T4ChampionEnteredTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        game = new Tournament("Olenka");
    }
    
    @After
    public void tearDown() {
    }

    
    // TODO add test methods here.
    
    /** Tests the successful entry of a champion, expects the result 0 which represents a successful entry
     * 
     */
     @Test
    public void oneChampionEnteredResult0() {
        int expected = 0;
        int actual= game.enterChampion("Flimsi");
        assertEquals(expected, actual);
    }
    
    /** Tests the correct amount of money is deducted when a champion is entered. expected result is 800 which is the default money amount, 1000, - 200, which is Flimsi's entry cost
     * 
     */
    @Test
    public void oneChampionEnteredTreasuryDeducted() {
        int expected = 800;
        game.enterChampion("Flimsi"); //don't store return
        int actual= game.getMoney();
        assertEquals(expected, actual);
    }
    
    /** Tests the champion has actually been added to the team by calling the isInPlayersTeam method parsing Flimsi as a parameter, the expected result is true
     * 
     */
    @Test
    public void oneChampionEnteredInTeam() {
        game.enterChampion("Flimsi"); 
        boolean actual= game.isInPlayersTeam("Flimsi");
        assertTrue(actual);
    }
    
    /** Tests that when a champion is entered they are not in the reserve anymore by entering flimsi and calling the isInReserve method parsing flimsi as a paramter, the expected result is false
     * 
     */
    @Test
    public void oneChampionNotInReserve() {
        game.enterChampion("Flimsi");
        boolean actual = game.isInReserve("Flimsi");
        assertFalse(actual);
    }
    
    /** Tests that tries to enter a champion twice, expected result should be 1 which represents a champion is not in reserve
     * 
     */
    @Test
    public void oneChampionNotEnteredTwice() {
        int expected = 1;
        game.enterChampion("Flimsi");
        int actual = game.enterChampion("Flimsi");
        assertEquals(expected, actual);
    }
    
    /** Tests that money is not decreased when trying to add a champion that cannot be afforded expected result is 400 which is 1000 - the cost of flimsi and ganfrank
     * 
     */
    @Test
    public void notEnoughMoney() {
        int expected = 400;
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        game.enterChampion("Argon");
        assertEquals(expected, game.getMoney());
    }
    
    /** Tests a champion is not added to the team if the player can't afforded them expected result is 2 which represents not enough money
     * 
     */
    @Test
    public void notEnoughMoneyResult2() {
        int expected = 2;
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        int actual = game.enterChampion("Argon");
        assertEquals(expected, actual);
    }
    
    /** checks to see if a champion is not in the team if the player has not enough money by calling the isInPlayersTeam method parsing Argon
     * 
     */
    @Test
    public void notEnoughMoneySoNotInTeam() {
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        game.enterChampion("Argon");
        boolean actual = !game.isInPlayersTeam("Argon");
        assertTrue(actual);
    }
    
    /** checks that a champion stays in the reserves if they don't have money
     * 
     */
    @Test
    public void notEnoughMoneySoStaysInReserve() {
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        game.enterChampion("Argon");
        boolean actual = (game.getReserve()).contains("Argon");
        assertTrue(actual);
    }
    
    /** Check that a champion that does not exist cannot be entered. Expected result is -1 which represents a champion that does not exist
     * 
     */
    @Test
    public void noSuchChampionEntered() {
        int expected = -1;
        int actual= game.enterChampion("Boggle");
        assertEquals(expected, actual);
    }
    
    /** checks that no money is deducted from the treasury if a player tries to enter a champion that does not exist, expected result should be 1000, the default value of the treasury
     * 
     */
    @Test
    public void oSuchCnhampionEnteredNoDeduction() {
        int expected = 1000;
        game.enterChampion("Boggle");
        int actual = game.getMoney();
        assertEquals(expected, actual);
    }
    
    @Test
    public void notEnoughMoneySoStaysInreserve() {
        game.enterChampion("Flimsi");
        game.enterChampion("Ganfrank");
        game.enterChampion("Argon");
        boolean actual = (game.getReserve()).contains("Argon");
        assertTrue(actual);
    }
    
}
