/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.io.Serializable;
/** Used to store information unique to the dragon champion type. Inherits common champion traits from the champion class
 *
 * @author mattc
 * @date 06/12/20
 */
public class Dragon extends Champion implements Serializable{
    private boolean talk;
    
    /** Used to set default values to the fields, the constructor of the parent class is called to set values for general champion traits
     * 
     * @param name name of the dragon
     * @param tlk boolean determining whether the dragon can or cannot talk
     */
    public Dragon(String name, boolean tlk)
    {
        super(name, 7, 500, "Dragon");
        talk = tlk;
    }
    
    /** Returns true if the dragon can talk and false if not
     * 
     * @return talk variable
     */
    public boolean canTalk()
    {
        return talk;
    }
    
    /** Returns a string representation of a dragon object, 
     *  calls the toString method of the parent class to a get a string of general champion traits that can be added on to, as warrior does not have direct access to those fields
     * 
     * @return String representation of the dragon
     */
    public String toString()
    {
        return super.toString() + "\nTalks: : " + talk + "\n";  
    }
    
}
