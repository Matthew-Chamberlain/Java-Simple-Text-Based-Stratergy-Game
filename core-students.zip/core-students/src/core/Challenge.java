/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

/** Used to store information about challenges including the number, the type, the enemy, the skill and the reward
 *
 * @author mattc
 */
public class Challenge {
    int challengeNumber;
    ChallengeType challengeType;
    String enemy;
    int requiredSkill;
    int reward;
    
    /** Used to set default values to the fields
     * 
     * @param number the challenge number
     * @param type the type of challenge (Magic, Fight or Mystery)
     * @param enemyName the name of the enemy
     * @param level the skill level required to beat the challenge
     * @param prize the reward amount
     */
    public Challenge(int number, ChallengeType type, String enemyName, int level, int prize)
    {
        challengeNumber = number;
        challengeType = type;
        enemy = enemyName;
        requiredSkill = level;
        reward = prize;
    }
    
    /** Returns the challenge number of the object
     * 
     * @return challengeNumber
     */
    public int getNumber()
    {
        return challengeNumber;
    }
    
    /** Returns the challenge type of the object
     * 
     * @return challengeType
     */
    public ChallengeType getType()
    {
        return challengeType;
    }
    
    /** Returns the name of the enemy
     * 
     * @return enemyName
     */
    public String getEnemy()
    {
        return enemy;
    }
    
    /** Returns the skill level needed to beat the challenge
     * 
     * @return requiredSkill
     */
    public int getSkillRequired()
    {
        return requiredSkill;
    }
    
    /** Returns the reward amount of the challenge
     * 
     * @return reward
     */
    public int getReward()
    {
        return reward;
    }
    
    /** Returns a string representation of the challenge
     * 
     * @return challenge info as string
     */
    public String toString()
    {
        return "\nChallenge Number: " + challengeNumber + "\nChallenge Type: " + challengeType + "\nEnemy Name: " + enemy + "\nRequired Skill: " + requiredSkill + "\nReward: " + reward + "\n";
    }
}
