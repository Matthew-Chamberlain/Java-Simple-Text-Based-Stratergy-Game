/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.io.Serializable;
/** Used to store information unique to the warrior champion type. Inherits common champion traits from the champion class
 *
 * @author mattc
 * @date 06/12/20
 */
public class Warrior extends Champion implements Serializable{
    private String weapon;
    
    /** Used to set default values to the fields, the constructor of the parent class is called to set values for general champion traits
     * 
     * @param name name of the warrior
     * @param fee entry fee of the warrior
     * @param wpon weapon of the warrior
     */
    public Warrior(String name, int fee, String wpon)
    {
        super(name, fee/100, fee, "Warrior");
        weapon = wpon;
    }
    
    /** Returns the weapon of the warrior as a string
     * 
     * @return returns weapon variable
     */
    public String getWeapon()
    {
        return weapon;
    }
    
    /** Returns a string representation of a warrior object, 
     *  calls the toString method of the parent class to a get a string of general champion traits that can be added on to, as warrior does not have direct access to those fields
     * 
     * @return string representation of a warrior
     */
    @Override
    public String toString()
    {
        return super.toString() + "\nWeapon: : " + weapon + "\n";  
    }
}
