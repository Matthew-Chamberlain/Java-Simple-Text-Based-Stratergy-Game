/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.io.Serializable;
/** Used to store information unique to the wizard champion type. Inherits common champion traits from the champion class
 *
 * @author mattc
 * @date 06/12/20
 */
public class Wizard extends Champion  implements Serializable{
    private boolean necromancer;
    private String specialitySpell;
    
    /** Used to set default values to the fields, the constructor of the parent class is called to set values for general champion traits
     * 
     * @param name name of the wizard
     * @param level skill level of the wizard
     * @param fee entry fee of the wizard
     * @param necro boolean stating whether the wizard is or is not a necromancer
     * @param spell Speciality spell of the wizard
     */
    public Wizard(String name, int level, int fee, boolean necro, String spell)
    {
        super(name, level, fee, "Wizard");
        necromancer = necro;
        specialitySpell = spell;
    }
    
    /** Returns true if the wizard is a necromancer and false if not
     * 
     * @return boolean necromancer
     */
    public boolean isNecormancer()
    {
        return necromancer;
    }
    
    /** Returns the speciality spell of the wizard
     * 
     * @return speciality spell variable
     */
    public String getSpell()
    {
        return specialitySpell;
    }
    
    /** Returns a string representation of a wizard object, 
     *  calls the toString method of the parent class to a get a string of general champion traits that can be added on to, as wizard does not have direct access to those fields
     * 
     * @return string representation of a wizard object
     */
    @Override
    public String toString()
    {
        return super.toString() + "\nNecormancer: " + necromancer + "\nSpeciality spell: " + specialitySpell + "\n";  
    }
}
