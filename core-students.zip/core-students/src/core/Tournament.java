package core;
import java.util.*;
import java.io.*;
/**
 * This class implements the behaviour expected from the CORE
* as required for 6COM1037 Cwk Assignment - Nov 2020
 * 
 * @author 
 * @version 05/10/20
 */

public class Tournament implements CORE
{
    // Fields
    private String playerName;
    private int money; 
    private HashMap<String, Champion> champions;
    private HashMap<Integer, Challenge> challenges;
    
    //**************** CORE ************************** 
    /** Constructor requires the name of the player
     * @param player the name of the player
     */  
    public Tournament(String pl)
    {
       playerName = pl;
       money = 1000;
       
       champions = new HashMap<String,Champion>();
       challenges = new HashMap<Integer, Challenge>();
       
       setupChampions();
       setupChallenges();
      
    }
    
    /**Constructor that is used to read in challenges from a file
     * 
     * @param pl player name
     * @param fileName name of file where challenges are stored
     */
    public Tournament(String pl, String fileName)
    {
       playerName = pl;
       money = 1000;
       
       champions = new HashMap<String,Champion>();
       challenges = new HashMap<Integer, Challenge>();
       
       setupChampions();
       readChallenges(fileName);
    }
    
    
    //******* Implements interface CORE *******************
    /**Returns a String representation of the state of the game,
     * including the name of the player, state of the treasury,
     * whether defeated or not, and the champions currently in the 
     * team,(or, "No champions" if team is empty)
     * 
     * @return a String representation of the state of the game,
     * including the name of the player, state of the treasury,
     * whether defeated or not, and the champions currently in the 
     * team,(or, "No champions" if team is empty)
     */
    public String toString() {
        
        return "Player Name: " + playerName + "\nTreasury amount: " + money + "\nDefeated: " + isDefeated() + "\n****************Champions In Team***************\n" + getTeam();
     }
  
    /** returns true if Treasury <=0 and the player's team has no 
     * champions which can be withdrawn. 
     * @returns true if Treasury <=0 and the player's team has no 
     * champions which can be decommissioned. 
     */
    public boolean isDefeated()
    {
        if(!anyActiveMembers() && money <= 0)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /** returns the amount of money in the Treasury
     * @returns the amount of money in the Treasury
     */
    public int getMoney(){
        
       return money;
    }    
    
    /**Returns a String representation of all champions in reserve
     * @return a String representation of all champions in reserve
     **/
    public String getReserve(){
        
        String s = "";
        Collection<Champion> reserve = champions.values();
        for(Champion temp : reserve)
        {
           if(isInReserve(temp.getName()))
           {
               s += temp.toString();
           }
        }
        if(s.equalsIgnoreCase("")){
            return "\nReserves empty";
        }
        else{
            return s;
        }
    }
       
    /** Returns details of any champion with the given name
     * @return details of any champion with the given name
     **/
    public String getChampionDetails(String nme){
       Champion temp = champions.get(nme);
        if(temp != null)
        {
            return temp.toString();
        }
        else
        {
            return "Champion does not exist!";
        }
    }
    
    /** returns whether champion is in reserve
    * @param champion's name
    * @return true if champion in reserve, false otherwise
    */
    public boolean isInReserve(String nme) {
        Champion temp = champions.get(nme);
        if(temp == null)
        {
            return false;
        }
        else if(temp.getState() == ChampionState.WAITING)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
 // ***************** Players Team************************   
    /** Allows a champion to be entered for the player's team, if there 
     * is enough money in the Treasury for the entry fee.The champion's 
     * state is set to "active"
     * 0 if champion is entered in the player's team, 
     * 1 if champion is not in reserve, 
     * 2 if not enough money in the treasury, 
     * -1 if there is no such champion 
     * @param nme represents the name of the champion
     * @return as shown above
     **/        
    public int enterChampion(String nme){
       Champion temp = champions.get(nme);
            if(temp == null){
                return -1;
            }
            else if(!isInReserve(nme))
            {
                return 1;
            }
            else if(money < temp.getEntryFee())
            {
                return 2;
            }
            else
            {
                money -= temp.getEntryFee();
                temp.setState(ChampionState.ACTIVE);
                return 0;
            }
    }
    
        
    /** Returns true if the champion with the name is in 
     * the player's team, false otherwise.
     * @param nme is the name of the champion
     * @return returns true if the champion with the name
     * is in the player's team, false otherwise.
     **/
    public boolean isInPlayersTeam(String nme){
        Champion temp = champions.get(nme);
        if(temp == null){
            return false;
        }
        else if(temp.getState() != ChampionState.WAITING)
        {
            return true;
        }
        else{
            return false;
        }
    }
    
    
    /** Removes a champion from the team to the reserves (if they are in the team)
     * Pre-condition: isChampion()
     * 0 - if champion is retired to reserves
     * 1 - if champion not retired because dead
     * 2 - if champion not retired because not in team
     * -1 - if no such champion
     * @param nme is the name of the champion
     * @return as shown above 
     **/
    public int retireChampion(String nme){
       Champion temp = champions.get(nme);
        if(temp == null){
            return -1;
        }
        else if(!isInPlayersTeam(nme))
        {
            return 2;
        }
        else if(temp.getState() == ChampionState.DEAD)
        {
            return 1;
        }
        else
        {
            money += (temp.getEntryFee() / 2);
            temp.setState(ChampionState.WAITING);
            return 0;
        }   
    }
        
        
    /**Returns a String representation of the champions in the player's team
     * or the message "No champions entered"
     * @return a String representation of the champions in the player's team
     **/
    public String getTeam(){
        String s = "";
        Collection<Champion> team = champions.values();
        for(Champion temp : team)
        {
           if(isInPlayersTeam(temp.getName()))
           {
               s += temp.toString();
           }
        }
        if(s.equalsIgnoreCase("")){
            return "\nTeam empty";
        }
        else{
            return s;
        }
    }
    
    
//**********************Challenges************************* 
    /** returns true if the number represents a challenge
     * @param num is the number of the challenge
     * @returns true if the number represents a challenge
     **/
     public boolean isChallenge(int num){
        if(challenges.get(num) != null)
        {
            return true;
        }
        else
        {
            return false;
        }
         
        
    }
     
    /** Provides a String representation of an challenge given by 
     * the challenge number
     * @param num the number of the challenge
     * @return returns a String representation of a challenge given by 
     * the challenge number
     **/
    public String getChallenge(int num){
        Challenge temp = challenges.get(num);
        if(isChallenge(num))
        {
            return temp.toString();
        }
        else
        {
            return "Challenge does not exist!";
        }
    }
    
    /** Provides a String representation of all challenges 
     * @return returns a String representation of all challenges
     **/
    public String getAllChallenges(){
        String s = "";
        Collection<Challenge> collection = challenges.values();
        for(Challenge temp : collection )
        {
           if(isChallenge(temp.getNumber()))
           {
               s += temp.toString();
           }
        }
        return s;
    }
    
    /** Retrieves the challenge represented by the challenge 
     * number.Finds a champion from the team which can challenge the 
     * challenge. The results of fighting an challenge will be 
     * one of the following:  
     * 0 - challenge won, add reward to the treasury, 
     * 1 - challenge lost on battle skills  - deduct reward from
     * treasury and record champion as "dead"
     * 2 - challenge lost as no suitable champion is  available, deduct
     * the reward from treasury 
     * 3 - If a challenge is lost and player completely defeated (no money and 
     * no champions to withdraw) 
     * -1 - no such challenge 
     * @param chalNo is the number of the challenge
     * @return an int showing the result(as above) of fighting the challenge
     */ 
    public int fightChallenge(int chalNo){
        
        if(!isChallenge(chalNo))
        {
            return -1;
        }
        Challenge tempChallenge = challenges.get(chalNo);
        Collection<Champion> team = champions.values();
        for(Champion tempChamp : team)
        {
            if(tempChamp.getState() == ChampionState.ACTIVE){
                if(compareType(tempChallenge.getType(), tempChamp))
                {
                    if(compareSkill(tempChallenge.getSkillRequired(), tempChamp.getSkillLevel()))
                    {
                        money += tempChallenge.getReward();
                        return 0;
                    }
                    else
                    {
                        money -= tempChallenge.getReward();
                        tempChamp.setState(ChampionState.DEAD);
                        return 1;
                    }
                }
            }
                
        }
        money -= tempChallenge.getReward();
        if(isDefeated())
        {
            return 3;
        }
        else
        {
            return 2;
        }
    }
  
// These methods are not needed until Task 4.4
    // ***************   file write/read  *********************
    /** Writes whole game to the specified file
     * @param fname name of file storing requests
     */
    public void saveGame(String fname){
        Collection<Champion> team = champions.values();
        try
        {
            FileOutputStream file = new FileOutputStream(fname);
            ObjectOutputStream outf  = new ObjectOutputStream (file);
            DataOutputStream dataf = new DataOutputStream(file);
            outf.writeUTF(playerName);
            outf.writeInt(money);
            outf.writeObject(champions);     
            outf.close();
        }
        catch(IOException e){}
       
    }
    
    /** reads all information about the game from the specified file 
     * and returns a CORE reference to a Tournament object
     * @param fname name of file storing the game
     * @return the game (as a Tournament object)
     */
    public CORE loadGame(String fname){
 
       try
       {
           FileInputStream fis = new FileInputStream(fname);
           ObjectInputStream ois  = new ObjectInputStream (fis);
           playerName = ois.readUTF();
           money = ois.readInt();
          
           champions = (HashMap<String, Champion>)ois.readObject();
           
           
           
       }
       catch (Exception e){}
       return null;
    }
    
    /**
     * reads challenges from a comma-separated textfile and stores
     * @param filename of the comma-separated textfile storing information about challenges
     */
    public void readChallenges(String filename){
        Challenge temp;
        int challengeNumber = 1;
        try
        {
            BufferedReader reader = new BufferedReader (new FileReader (filename));   
            String line = reader.readLine();
            while(line != null)
            {
                String[] elements = line.split(",");
                ChallengeType type = ChallengeType.valueOf(elements[0].toUpperCase());
                int level = Integer.parseInt(elements[2]);
                int prize = Integer.parseInt(elements[3]);
                challenges.put(challengeNumber, new Challenge(challengeNumber, type, elements[1], level, prize));
                challengeNumber++;
                line = reader.readLine();
            }
        }
        catch(Exception e){}
        
        
    }
    
    /** Private method used to load in wizard, warrior and dragon objects into the hashmap of champions
     * 
     */
    private void setupChampions()
    {
        champions.put("Ganfrank", new Wizard("Ganfrank", 7, 400, true, "transmutation"));
        champions.put("Rudolf", new Wizard("Rudolf", 6, 400, true, "invisibility"));
        champions.put("Elblond", new Warrior("Elblond", 150, "sword"));
        champions.put("Flimsi", new Warrior("Flimsi", 200, "bow"));
        champions.put("Drabina", new Dragon("Drabina", false));
        champions.put("Golum", new Dragon("Golum", true));
        champions.put("Argon", new Warrior("Argon", 900, "mace"));
        champions.put("Neon", new Wizard("Neon", 2, 300, false, "translocation"));
        champions.put("Xenon", new Dragon("Xenon", true));
        champions.put("Atlanta", new Warrior("Atlanta", 500, "bow"));
        champions.put("Krypton", new Wizard("Krypton", 8, 300, false, "fireballs"));
        champions.put("Hedwig", new Wizard("Hedwig", 1, 400, true, "flying"));
    }
    
    /** Private method used to load challenges into the challenges hashmap
     * 
     */
    private void setupChallenges()
    {
        challenges.put(1, new Challenge(1, ChallengeType.MAGIC, "Borg", 3, 100));
        challenges.put(2, new Challenge(2, ChallengeType.FIGHT, "Huns", 3, 120));
        challenges.put(3, new Challenge(3, ChallengeType.MYSTERY, "Ferengi", 3, 150));
        challenges.put(4, new Challenge(4, ChallengeType.MAGIC, "Vandal", 9, 200));
        challenges.put(5, new Challenge(5, ChallengeType.MYSTERY, "Borg", 7, 90));
        challenges.put(6, new Challenge(6, ChallengeType.FIGHT, "Goth", 8, 45));
        challenges.put(7, new Challenge(7, ChallengeType.MAGIC, "Frank", 10, 200));
        challenges.put(8, new Challenge(8, ChallengeType.FIGHT, "Sith", 10, 170));
        challenges.put(9, new Challenge(9, ChallengeType.MYSTERY, "Cardashian", 9, 300));
        challenges.put(10, new Challenge(10, ChallengeType.FIGHT, "Jute", 2, 300));
        challenges.put(11, new Challenge(11, ChallengeType.MAGIC, "Celt", 2, 250));
        challenges.put(12, new Challenge(12, ChallengeType.MYSTERY,"Celt", 1, 250));
    }
    
    
    /** Private method used to compare the type of a challenge to the type of a champion, called in the fightChallenge method to determine if a champion can fight a challenge
     * 
     * @param challengeType type of the challenge (Magic, Fight, Mystery))
     * @param tempChamp a champion object containing a reference to an existing wizard, warrior or dragon object.
     * @return a boolean stating whether the champion can fight in the given challenge or not
     */
    private boolean compareType(ChallengeType challengeType, Champion tempChamp)
    {
        if(challengeType == ChallengeType.MAGIC)
        {
            if(tempChamp.getType().equals("Wizard")){
                return true;
            }
            else
            {
                return false;
            }
        }
        else if(challengeType == ChallengeType.MYSTERY)
        {
            if(tempChamp.getType().equals("Wizard") || (tempChamp.getType().equals("Dragon") && ((Dragon)tempChamp).canTalk() == true))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        else
        {
            return true;
        }
    }
    
    /** Private method used to compare the skill of a champion to the skill required to beat a challenge Called in the fightChallenge method to determine whether or not a champion will win the challenge
     * 
     * @param skillRequired skill required to beat the challenge
     * @param skillLevel skill level of the champion
     * @return boolean stating if the champions skill level is equal to or greater than the skill required or not
     */
    private boolean compareSkill(int skillRequired, int skillLevel)
    {
        if(skillLevel >= skillRequired)
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    /** Private method used to check if there is at least one active member in the map of champions. Used in the isDeafeated method to check whether there are champions that can still be withdrawn
     * 
     * @return  boolean stating whether there is at least one active champion in the map of champions or not
     */
    private boolean anyActiveMembers()
    {
        Collection<Champion> reserve = champions.values();
        for(Champion temp : reserve)
        {
            if((isInPlayersTeam(temp.getName()) && temp.getState() == ChampionState.ACTIVE))
            {
                return true;
            }
        }
        return false;
    }
}



