package core;

import java.io.*;
/**
 * Enumeration class ChallengeType - specifies all types a challenge can be
 * 
 * @author mattc
 * @version 06/12/20
 */
public enum ChallengeType implements Serializable
{
    MAGIC(" Magic"), FIGHT("Fight"), MYSTERY ("Mystery");
    private String type;
    
    private ChallengeType(String ty)
    {
        type = ty;
    }
    
    /** returns a string representation of the type
     * 
     * @return type of challenge as string
     */
    public String toString()
    {
        return type;
    }
}
