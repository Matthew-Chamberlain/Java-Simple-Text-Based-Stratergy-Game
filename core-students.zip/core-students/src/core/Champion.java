/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package core;

import java.io.Serializable;

/** Used to store all general information that all types of champions share. It is an abstract class as champion objects are not created, types of champions such as wizard are created.
 *
 * @author mattc
 * @date 06/12/20
 */
public abstract class Champion implements Serializable {
    private String name;
    private int skillLevel;
    private int entryFee;
    private String type;
    private ChampionState state;
    
    /** Used to set default values to the fields of objects that inherit from the champion class
     * 
     * @param nme the name of the champion
     * @param level the skill level of the champion
     * @param fee the entry fee of the champion
     * @param typ the type of the champion (wizard, warrior, dragon)
     */
    public Champion(String nme, int level, int fee, String typ)
    {
        name = nme;
        skillLevel = level;
        entryFee = fee;
        type = typ;
        state = ChampionState.WAITING;
       
    }
    
    /** Returns the name of the object
     * 
     * @return champion name
     */
    public String getName()
    {
        return name;
    }
    
    /** Returns the skill level of the object
     * 
     * @return skill level
     */
    public int getSkillLevel()
    {
        return skillLevel;
    }
    
    /** Returns the entry fee of the object
     * 
     * @return entry fee
     */
    public int getEntryFee()
    {
        return entryFee;
    }
    
    /** Returns the type of the object
     * 
     * @return type
     */
    public String getType()
    {
        return type;
    }
    
    /** Returns the state of the object (Waiting, Alive or Dead)
     * 
     * @return state
     */
    public ChampionState getState()
    {
        return state;
    }
    
    /** Used to update the state to a new state that is provided by a parameter
     * 
     * @param newState represents the new state that will be stored in the object
     */
    public void setState(ChampionState newState)
    {
        state = newState;
    }
    
    /** Returns a string representation of the object
     * 
     * @return string representation
     */
    public String toString()
    {
        return "\nName: " + name + "\nSkill Level: " + skillLevel + "\nEntry Fee: " + entryFee + "\nType: " + type + "\nState: " + state.toString();
    }
       
}
